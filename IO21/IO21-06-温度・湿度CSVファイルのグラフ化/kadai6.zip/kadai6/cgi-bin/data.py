#!/usr/bin/python3
import os
import csv
import json
import datetime
from urllib.parse import parse_qs

CSV_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'kadai5.csv')

# import cgi の代わりに、環境変数 QUERY_STRING からパラメータを取り出す
params = parse_qs(os.environ.get('QUERY_STRING', ''))
try:
    hours = float(params.get('hours', ['0'])[0])
except ValueError:
    hours = 0

records = []
if os.path.exists(CSV_FILE):
    with open(CSV_FILE, encoding='utf-8', newline='') as f:
        for row in csv.reader(f):
            if len(row) != 3:
                continue
            try:
                t = datetime.datetime.strptime(row[0].strip(), '%Y-%m-%d %H:%M:%S')
                records.append((t, float(row[1]), float(row[2])))
            except ValueError:
                continue

# hours > 0 のときは、最新の記録から hours 時間分だけに絞る（0 は全期間）
if hours > 0 and records:
    since = records[-1][0] - datetime.timedelta(hours=hours)
    records = [r for r in records if r[0] >= since]

result = {
    'times': [r[0].strftime('%Y-%m-%d %H:%M:%S') for r in records],
    'temperature': [r[1] for r in records],
    'humidity': [r[2] for r in records],
}

print('Content-Type: application/json; charset=utf-8')
print('Cache-Control: no-store')
print()
print(json.dumps(result))
